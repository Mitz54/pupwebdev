<?php
$dbServerName = "localhost";
$dbUsername = "root";
$dbpassword = "";
$dbname = "pup";

$conn = mysqli_connect($dbServerName, $dbUsername, $dbpassword, $dbname);
?>