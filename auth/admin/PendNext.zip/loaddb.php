<?php
	include_once 'includes/databse.php';
	session_start();
	$num1 = $_POST['profNewCount'];
	$profNewCount = $_SESSION['PendingNum'];
	$queueCount = $_SESSION['PendingNum']+$num1;

				echo $queueCount;
?>
