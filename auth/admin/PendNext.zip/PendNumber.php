<?php
	session_start();
	include_once 'includes/databse.php';
	$num = $_POST['queueNewCount'];
	$dateToday = date("Y-m-d");
	$remarks = $_SESSION['remarks'];
	$staffID = $_SESSION['accntID'];
	if($num == 1){
		$profNewCount = $_SESSION['PendingNum'];
}
else {
	$profNewCount = $_SESSION['PendingNum'] + $num - 1;
}

	//$sql2 = "UPDATE `queueingtransaction` SET `queueingTransactionStatus` = 'Pending' WHERE `queueingtransaction`.`queueingTransactionID` = $profNewCount;";
	$result2 = mysqli_query($conn,"call UpdatePending('$profNewCount','$dateToday','$staffID')");
	//$sql = "UPDATE `queueingtransaction` SET `Remarks` = '$remarks' WHERE `queueingtransaction`.`queueingTransactionID` = $profNewCount;";
	$result = mysqli_query($conn,"call updatePendTable('$remarks','$profNewCount','$dateToday','$staffID')");
?>
