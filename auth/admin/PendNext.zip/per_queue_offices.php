<?php session_start(); ?>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/pupwebdev-kiosk/auth/header.php' ?>
<?php	include_once 'includes/databse.php';?>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/CSS/bootstrap.min.css" rel="stylesheet" >
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="/pupwebdev-kiosk/assets/stylesheet/admin.css" >

<style type="text/css">
    .con
    {
      margin-top: 10px;
    }
    .htext
    {
      margin-top:120px;
    }
    .pupcolor
    {
      background-color: #7f0400;
    }
    .modaladjust
    {
      margin-top: 100px;
    }
    .btnadjust
    {
      height: 75px;
    }
    .contest
    {
      background-color: red;
      height: 500px;
    }
    .textsize
    {
      font-size: 24pt;
    }
      .card-header {
    background-color: #a12c28;
    color: white;
    width: 100%;
    margin-bottom: -100px;
  }
  .table-wrapper-scroll-y {
    display: block;
    max-height: 270px;
    overflow-y: auto;
    -ms-overflow-style: -ms-autohiding-scrollbar;
  }

</style>

<div class="container-fluid">
  <div class="row">
    <div class="card-header">
      <h1 class="text-white htext" id="transactionNum">
            <?php
            //session_start();
            $dateToday = date("Y-m-d");
            $staffID = $_SESSION['accntID'];
						$sql = "SELECT queue.queueNumber FROM `queueingtransaction` INNER JOIN transaction ON transaction.transactionID = queueingtransaction.transactionID_FK INNER JOIN queue ON queue.queueNumber = queueingtransaction.queueID_FK INNER JOIN office ON office.officeID = transaction.officeID_FK where queueingTransactionStatus = 'Waiting' and queueingTransactionDate = '$dateToday' and office.staffID_FK = $staffID LIMIT 1";
						$result = mysqli_query($conn,$sql);
						$resultCheck = mysqli_num_rows($result);
						if ($resultCheck > 0) {
							while ($row = mysqli_fetch_assoc($result)) {
                $_SESSION['PendingNum'] = $row['queueNumber'];
								}
							}
						else{
							echo "No more professors";
							}
						//	$_SESSION['PendingNum'] = implode($array[0], " ");
						echo $_SESSION['PendingNum'];
						 ?> </h1>
         <button class="btn btn-info next" type="submit" id="button03" style="float: right; margin-top: -50px;">Next</button>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6 htext">
      <div class="container ">
        <h1 class="text-white">Queue</h1>
          <div class="row">
            <div class="col-12 con">
              <div class="card">
                <div class="card-body">
                  <div class="table-wrapper-scroll-y">
                      <table class="table table-bordered table-hover table-striped">
                      <thead class="thead-light">
                        <tr>
                          <th scope="col">Queue Number</th>
                          <th scope="col">Transactions</th>
                          <th scope="col">Date Queue</th>
                        </tr>
                      </thead>
                      <tbody id = "queueTable">
                      <?php
                      $dateToday = date("Y-m-d");
                      $staffID = $_SESSION['accntID'];
								$sql = "SELECT queue.queueNumber, transaction.transaction, queueingtransaction.queueingTransactionDate, queueingTransaction.queueingTransactionStatus, transaction.officeID_FK FROM queueingtransaction INNER JOIN transaction ON transaction.transactionID = queueingtransaction.transactionID_FK INNER JOIN queue ON queue.queueNumber = queueingtransaction.queueID_FK INNER JOIN office ON office.officeID = transaction.officeID_FK WHERE queueingTransactionStatus = 'Waiting' and queueingTransactionDate = $dateToday and office.staffID_FK = $staffID;";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);
								if ($resultCheck > 0) {
								while ($row = mysqli_fetch_assoc($result)) {
									$array[] = $row;
									echo "<tr><td>" . $row['queueNumber'] . "</td>" ."<td>".$row['transaction']. "</td>"."<td>".$row['queueingTransactionDate'].  "</td></tr>";
									}
								}
							?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>

    <div class="col-sm-6 htext">
      <div class="container ">
        <h1 class="text-white">Pending</h1>
          <div class="row">
            <div class="col-12 con">
              <div class="card">
                <div class="card-body">
                  <div class="table-wrapper-scroll-y">
                      <table class="table table-bordered table-hover table-striped">
                      <thead class="thead-light">
                        <tr>
                          <th scope="col-sm-4">Queue Number</th>
                          <th scope="col-sm-4">Date Pend</th>
                          <th scope="col-sm-4">Remarks</th>
                          <th scope="col-sm-4">Actions</th>
                        </tr>
                      </thead>
                      <tbody id = "pendTable">
                      <?php
                      $staffID = $_SESSION['accntID'];
                      $dateToday = date("Y-m-d");
                $sql = "SELECT queue.queueNumber, transaction.transaction, queueingtransaction.queueingTransactionDate, queueingTransaction.queueingTransactionStatus, transaction.officeID_FK FROM queueingtransaction INNER JOIN transaction ON transaction.transactionID = queueingtransaction.transactionID_FK INNER JOIN queue ON queue.queueNumber = queueingtransaction.queueID_FK INNER JOIN office ON office.officeID = transaction.officeID_FK WHERE queueingTransactionStatus = 'Pending' and queueingTransactionDate = $dateToday and office.staffID_FK = $staffID;";
                $result = mysqli_query($conn, $sql);
                $resultCheck = mysqli_num_rows($result);

                while ($row = mysqli_fetch_array($result)) {
                  $array[] = $row;
                  $qtID = $row['queueingTransactionID'];
                  echo '<tr>
                          <td>'. $row['queueNumber'].'</td>
                          <td>'.$row['transaction'].'</td>
                          <td>'.$row['Remarks'].'</td>'.
                          '<td><a href="deletePending.php?qtID='.$qtID.'" class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></td>
                        </tr>';
                  }
              ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
  <br><br><br>
  <div class="row">
    <div class="col">
    <form action = "per_queue_offices.php" method = "post">
      <input class="btn btn-info pend" type="submit" id="pendBut" name ="submit" value = "Pend" style="margin: -50px 0px 0px 720px;"/>
      <div class="col-sm-4">
      <input class="textbox-selected" style="position: absolute; margin: -55px 0px 0px 800px;" type="text" name="user" placeholder="Pend" autocomplete="off"required/>
      </form>
      
  <?php
if(isset($_POST['submit'])){
  $_SESSION['remarks'] = $_POST['user'];
  }
    ?>
    </div>
    </div>
  </div>
</div>




<?php include $_SERVER['DOCUMENT_ROOT'] . '/pupwebdev-student/auth/footer.php' ?>

<script src="/pupwebdev-student/auth/admin/scripts/Course.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		var profcount =  0;
		var qCount =  0;
		$("#button03").click(function(){
			profcount = profcount + 1;
			qCount = qCount + 1;
			$.ajax({
				url:"queueTable.php",
				method:"POST",
				data:{queueNewCount: qCount},
			});
      $("#transactionNum").load("loaddb.php", {profNewCount: profcount});
		});
		$("#pendBut").click(function(){
			profcount = profcount + 1;
			qCount = qCount + 1;
			$.ajax({
				url:"PendNumber.php",
				method:"POST",
				data:{queueNewCount: qCount},
			});
      $("#transactionNum").load("loaddb.php", {profNewCount: profcount});
		});
		setInterval(function(){
			$('#queueTable').load("loadQueueTable.php");
		}, 100);
    setInterval(function(){
			$('#pendTable').load("loadPendTable.php");
		}, 1500);
	});
</script>
