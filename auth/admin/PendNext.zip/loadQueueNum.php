<?php
	include_once 'includes/databse.php';
	$dateToday = date("Y-m-d");
	$result = mysqli_query($conn, "call selectQueueNumber('$dateToday')");
	$resultCheck = mysqli_num_rows($result);
						if ($resultCheck > 0) {
							while ($row = mysqli_fetch_assoc($result)) {
							$array[] = $row;
								}
							}
						else{
							echo "No more Students";
							}
							$_SESSION['PendingNum'] = implode($array[0], " ");
						echo $_SESSION['PendingNum'];
		}
	
